from django.apps import AppConfig


class ScheduleAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'schedule_app'
